#include <stdio.h>

int main ()
{
	int *pti; // Declarando um ponteiro de forma correta;
	
	/*
		*int pti  [ERRADO]
		*  pti    [ERRADO]
		&pti      [ERRADO]
		int _pti; [ERRADO]
	*/	
	return 0;
}
