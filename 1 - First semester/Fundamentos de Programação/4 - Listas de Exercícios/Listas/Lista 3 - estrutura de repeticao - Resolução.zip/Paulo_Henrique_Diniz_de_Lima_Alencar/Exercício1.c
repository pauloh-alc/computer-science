#include <stdio.h>

int main(){
	// Exerc�cio 1 - 
	
	int N, numero;
	printf("Entre com um numero inteiro N >>> ");
	scanf("%d",&numero);
	for(N = 1; N <= numero ; N++){
		printf("%d ",N);
	}
	printf("\n\n");
return 0;
}
